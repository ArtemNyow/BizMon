// Імпорт необхідних модулів
import { modals } from './modal.js';
import { setupAuthHandlers } from './auth.js';
import { initHeaderUser } from './header.js';
import { initScrollToTop } from './scroll-to-top.js';
import { initFAQ } from './faq.js'; // якщо є така функція
// import { initAuthModal } from './auth-modal.js'; // якщо там є логіка

document.addEventListener("DOMContentLoaded", () => {
  // Ініціалізація модальних вікон
  modals.init();

  // Прив'язка обробників для логіну/реєстрації
  setupAuthHandlers(modals);

  // Ініціалізація логіки хедера (відображення юзера)
  initHeaderUser();

  // Прокрутка вгору
  initScrollToTop();

  // Часті питання (FAQ)
  initFAQ();

  // Додаткові модалки (якщо є окрема логіка)
//   initAuthModal();
});
