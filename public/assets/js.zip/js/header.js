export function showUserHeader(name) {
  const userInfo = document.getElementById("user-info");
  const userName = document.getElementById("user-name");
  const userAvatar = document.getElementById("user-avatar");

  userName.textContent = name;

  const colors = ['#02897a', '#ec5f67', '#f6c344', '#4a90e2', '#8e44ad'];
  const bgColor = colors[Math.floor(Math.random() * colors.length)];
  userAvatar.style.backgroundColor = bgColor;
  userAvatar.textContent = name.charAt(0).toUpperCase();

  userInfo.classList.remove("is-hidden");
  document.querySelectorAll(".open-modal-btn").forEach(btn => btn.classList.add("is-hidden"));
}
